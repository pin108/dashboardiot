<x-app-layout>
    </x-slot>
</x-app-layout>
